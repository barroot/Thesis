<?php
/* Displays user information and some useful messages */
session_start();

// Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: error.php");    
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Vets</title>
    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><h4><i class= "fa fa-paw"> Pet's Health</i></h4></a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                       <i class= "fa fa-paw"></i>
                    </a>
                     <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-paw"></i> Pet's Health</a>
                        </li>
                    </ul>
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar">
                        </li>
                        <li class="active">
                            <a><i class="fa fa-dashboard fa-fw"></i><b> Dashboard</b><span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addPet.php"><i class="fa fa-cloud-upload"></i> Add Pet <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                <li>
                                     <a href="myPets.php"><i class="fa fa-paw"></i> My Pets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="petSitters.php"><i class ="fa fa-user"></i> Pet Sitters <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="profile.php"><i class ="fa fa-reply"></i> Back <i class="fa fa-hand-o-left"></i></a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <!-- Page Content -->
        <div id="page-wrapper">
              
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"> <i class="fa fa-user-md"> Vet Clinics in Ireland </i></h3>
                    <style>
                        #map{
                        height:600px;
                        width:100%;
                        }
                    </style>
            <div id="map"></div>
        <script>
        function initMap(){
        // Map options
        var options = {
        zoom:11,
        center:{lat:53.3603142,lng:-6.3150542}
        }

        // New map
       var map = new google.maps.Map(document.getElementById('map'), options);
      // Array of markers
       var markers = [
        {
          coords:{lat:53.3523022,lng:-6.2981043},
          //iconImage:'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png',
          content:'<h3>Cara Veterinary Clinic <br> Address: 1A N Circular Rd, Phoenix Park Gate, Dublin 7 <br> Phone:(01) 838 8338 <br> Review: 3.8 of 5 <br> Website:<a href="http://www.caravetgroup.com/"> www.caravetgroup.com </a> </h3>'
        },
        {
          coords:{lat:53.3610193,lng:-6.2827127},
          content:'<h3>Cara Veterinary Hospital <br> Address: 87 New Cabra Road Phibsboro, Dublin 7<br> Phone:(01) 868 0119 <br> Review: 4.7 of 5 <br> Website:<a href="https://www.villagevets.ie/"> www.villagevets.ie </a> </h3>'
        },
        {
          coords:{lat:53.3411086,lng:-6.3013854},
          content: '<h3>Carey & Keane Veterinary Surgeons <br> Address:Veterinary Clinic 12 Old Kilmainham, Kilmainham, Dublin 8, D08 TY09<br> Phone:	(01) 679 1975 <br> Review: 4.8 of 5 <br> Website:<a href="http://www.dublinvets.ie/"> www.dublinvets.ie</a> </h3> '
        },
         {
          coords:{lat:53.3306899,lng:-6.2606615},
          content: '<h3>Animal Welfare Clinic <br> Address: 40 Charlemont St, Saint Kevins, Dublin 2, D02 AE42<br> Phone: (01) 478 4348<br> Review: 4.4 of 5 <br> Website:<a href="http://animalwelfareclinic.ie/"> animalwelfareclinic.ie</a> </h3> '
        },
        {
          coords:{lat:53.3825337,lng:-6.2062855},
          content: '<h3>Amy Lara Clinic <br> Address: 43 Malahide Road, Artane Roundabout, Clontarf, Artane, Co. Dublin<br> Phone: (01) 846 5107<br> Review: 4.4 of 5 <br> Website:<a href="http://www.amylaravetclinic.ie/"> www.amylaravetclinic.ie</a> </h3>'
        },
        {   
         coords:{lat:53.3674589,lng:-6.2275615},
         content: '<h3>Clontarf Veterinary Hospital <br> Address: 66 Malahide Rd, Clontarf, Dublin 3, D03 RD42<br> Phone:(01) 833 0744<br> Review: 4.8 of 5 <br> Website:<a href="http://anicare.ie/"> anicare.ie</a> </h3>'
        },
        {   
         coords:{lat:53.3900797,lng:-6.2994012},
         content: '<h3>Fox Veterinary Clinic <br> Address: 7 Drogheda Mall, Main Street, Finglas East, Dublin, D11H778<br> Phone:(01) 834 8411<br> Review: 4.3 of 5 <br> Website:<a href="http://www.goldenpages.ie/ms/ms/fox-veterinary-clinic-contact-dublin-d11/ms-90043796-p-3/">www.goldenpages.ie</a> </h3>'
        },    
        {
         coords:{lat:53.3218816,lng:-6.3932809},
         content: '<h3>Clondalkin Clinic <br> Address: Orchard Rd, Clondalkin, Dublin<br> Phone:(01) 457 4833<br> Review: 4.2 of 5 <br> Website:<a href="https://www.clondalkinvet.com/">www.clondalkinvet.com</a> </h3>'
        },
        {
         coords:{lat:53.2458855,lng:-6.1358257},
         content: '<h3>Cherrywood Vet Clinic <br> Address: 5 Bray Rd, Dublin 18<br> Phone:(01) 282 6464<br> Review: 4.1 of 5 <br> Website:<a href="http://cherrywoodvetclinic.ie/">www.cherrywoodvetclinic.ie</a> </h3>'
        },
        {
         coords:{lat:53.29151,lng:-6.246313},
         content: '<h3> Dundrum Veterinary Clinic (South Dublin Vets)<br> Address: Dundrum Village Centre (Old Dundrum Shopping Centre), Main Street Dundrum, Dundrum, Dublin 14<br> Phone:(01) 296 5876<br> Review: 4.9 of 5 <br> Website:<a href="http://www.southdublinvets.ie/">www.southdublinvets.ie</a> </h3>'
        },
        {
         coords:{lat:53.2886733,lng:-6.2158694},
         content: '<h3> Ark Vetcare <br> Address: 114 Lower Kilmacud Rd, Stillorgan, Dublin, A94 CC65<br> Phone: (01) 278 0480<br> Review: 4.8 of 5 <br>  Website:<a href="http://www.arkvet.ie/">www.arkvet.ie</a></h3>'
        },
        {
         coords:{lat:53.2894593,lng:-6.1810032},
         content: '<h3> Blackrock Veterinary Clinic <br> Address: Wilton Cottage, 25 Stillorgan Park, Blackrock, Co. Dublin<br> Phone: (01) 288 9641<br> Review: 5.0 of 5 <br>  Website:<a href="http://blackrockvet.ie/">blackrockvet.ie</a></h3>'
        },
        {
         coords:{lat:53.288512,lng:-6.143988},
         content: '<h3>Primrose Hill Veterinary Clinic <br> Address: Tivoli Rd, Monkstown, Dublin<br> Phone:(01) 280 3303<br> Review: 4.8 of 5 <br> Website:<a href="http://primrosehillvets.ie/">primrosehillvets.ie</a> </h3>'
        },
        {
         coords:{lat:53.2806031,lng:-6.1203356},
         content: '<h3> Sandycove Veterinary Clinic <br> Address: Killiney View, 1 Newtownpark Ave, Glenageary, Blackrock, Co. Dublin <br> Phone:(01) 214 0510<br> Review: 4.8 of 5 <br> Website:<a href="http://www.sandycovevetsurgeon.com/">www.sandycovevetsurgeon.com </a> </h3>'
        },
        {
         coords:{lat:53.3597944,lng:-6.1896921},
         content: '<h3> Bull Wall Veterinary Clinic <br> Address: 24 Conquer Hill Rd, Clontarf, Dublin 3 <br> Phone: (01) 853 1260 <br> Review: 4.9 of 5 <br> </h3>'
        },
        {
         coords:{lat:53.3628052,lng:-6.2376051},
         content: '<h3> Fairview Veterinary Hospital <br> Address: 13 Fairview Strand, Clontarf, Dublin 3 <br> Phone: (01) 833 8217<br> Review: 4.7 of 5 <br> Website:<a href="http://www.fairviewvet.ie/">www.fairviewvet.ie</a> </h3>'
        },
        {
         coords:{lat:53.2812768,lng:-6.3418713},
         content: '<h3> Firhouse Veterinary Clinic <br> Address: 15, Firhouse Shopping Centre, Tymon South, Dublin 24 <br> Phone: (01) 414 0830<br> Review: 5.0 of 5 <br> Website:<a href="http://www.firhousevets.ie/book-appointment/">www.firhousevets.ie</a> </h3>'
        },
        {
         coords:{lat:53.2893086,lng:-6.3476384},
         content: '<h3> The Animal Hospital  <br> Address: 37A Main Rd, Tallaght, Co. Dublin <br> Phone: (01) 451 5930<br> Review: 4.6 of 5 <br> Website:<a href="http://animalhospital.ie/"> animalhospital.ie </a> </h3>'
        },
        {
         coords:{lat:53.3212831,lng:-6.3899388},
         content: '<h3> Castle Veterinary Clinic <br> Address: 6A Castle Park, Clondalkin, Dublin <br> Phone: (01) 464 0499<br> Review: 4.9 of 5 <br> Website:<a href="http://www.castlevets.ie/"> www.castlevets.ie </a> </h3>'
        },
        {
         coords:{lat:53.3115387,lng:-6.3070371},
         content: '<h3> Terenure Veterinary Hospital (South Dublin Vets) <br> Address: 30 Whitehall Rd, Terenure, Dublin 12, D12 ET82 <br> Phone: (01) 455 5362 <br> Review: 4.7 of 5 <br> Website:<a href="http://www.southdublinvets.ie/"> www.southdublinvets.ie </a> </h3>'
        },
        {
         coords:{lat:53.2968106,lng:-6.2963116},
         content: '<h3> Rathfarnham Veterinary Clinic <br> Address: 6 Fairways, Rathfarnham, Dublin 14 <br> Phone:(01) 493 1508 <br> Review: 4.7 of 5 <br> Website:<a href="http://www.rathfarnhamvet.com/">www.rathfarnhamvet.com </a> </h3>'
        },
        {
         coords:{lat:53.2878756,lng:-6.1958898},
         content: '<h3> Village Vets Stillorgan <br> Address: Glenalbyn Rd, Stillorgan, Dublin, A94 YW54 <br> Phone: (01) 288 8486 <br> Review: 5.0 of 5 <br> Website:<a href="https://www.villagevets.ie/">www.villagevets.ie</a> </h3>'
        },
         {
         coords:{lat:53.2103824,lng:-6.1213674},
         content: '<h3> Brayvet<br> Address: Old Connaught Ave, Cork Great, Bray, Co. Wicklow<br> Phone: (01) 282 1909 <br> Review: 4.4 of 5 <br> Website:<a href="http://www.brayvet.com/">www.brayvet.com</a> </h3>'
        },
        {
         coords:{lat:53.2007129,lng:-6.1126516},
         content: '<h3> Bairbre OMalley Veterinary <br> Address: 7 Kilmantain Pl, Bray, Co. Wicklow, A98 NY03<br> Phone: (01) 272 3857 <br> Review: 4.8 of 5 <br> Website:<a href="http://www.veterinary.ie/">www.veterinary.ie</a> </h3>'
        },
        {
         coords:{lat:53.2034387,lng:-6.107948},
         content: '<h3> Florence Road Vets<br> Address: 9 Florence Rd, Bray, Co. Wicklow, A98 W089 Florence Rd, Bray, Co. Wicklow, A98 W089<br> Phone: (01) 282 9589 <br> Review: 4.8 of 5 <br> Website:<a href="http://www.greystonesvet.ie/about_us_bray.htm">www.greystonesvet.ie</a> </h3>'
        },
        {
         coords:{lat:54.5017362,lng:-8.1938602},
         content: '<h3> Old Church Veterinary Hospital (XL Vets Ireland)<br> Address: The Mall, Townparks, Ballyshannon, Co. Donegal<br> Phone: (071) 985 1559 <br> Review: 4.2 of 5 <br> Website:<a href="http://www.oldchurchveterinaryhospital.com/">www.oldchurchveterinaryhospital.com</a> </h3>'
        },
        {
         coords:{lat:53.6327935,lng:-8.1870722},
         content: '<h3> All Creatures Veterinary Clinic (XL Vets Ireland)<br> Address: Lanesboro Street, Cloonbrackna, Roscommon Town, Co. Roscommon<br> Phone: (090) 662 6898 <br> Review: 4.6 of 5 <br> Website:<a href="http://www.allcreatures.ie/">www.allcreatures.ie</a> </h3>'
        },
        {
         coords:{lat:52.8487094,lng:-8.9728469},
         content: '<h3> Ennis Veterinary Clinic<br> Address: Clon Rd, Cappahard, Ennis, Co. Clare<br> Phone: (065) 679 7444 <br> Review: 4.8 of 5 <br> Website:<a href="http://www.ennisvetclinic.ie/">www.ennisvetclinic.ie</a> </h3>'
        }   
            
      ];

      // Loop through markers
      for(var i = 0;i < markers.length;i++){
        // Add marker
        addMarker(markers[i]);
      }

      // Add Marker Function
        function addMarker(props){
        var marker = new google.maps.Marker({
        position:props.coords,
        map:map,
          //icon:props.iconImage
        });

        // Check for customicon
        if(props.iconImage){
          // Set icon image
          marker.setIcon(props.iconImage);
        }

        // Check content
        if(props.content){
          var infoWindow = new google.maps.InfoWindow({
          content:props.content
          });
          marker.addListener('click', function(){
          infoWindow.open(map, marker);
          });
        }
      }
    }
   </script>
     <script async defer
     src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDVd4cqLgp8SJ9m9R2tx9iIMHgk-sYkeAI&callback=initMap">
  </script>
     </div>
        <!-- /.col-lg-12 -->
        </div>
            <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
 
</body>
</html>
