<?php
/* Registration process, inserts user info into the database 
 */
error_reporting(0);
require 'db.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['vaccination'])) {

        
    }
// Escape all $_POST variables to protect against SQL injections
$vacc_type = $mysqli->escape_string($_POST['vacc_type']);
$issue_date = $mysqli->escape_string($_POST['issue_date']);
$vet_name = $mysqli->escape_string($_POST['vet_name']);

      
// Check if user with the pet already exists
$result = $mysqli->query("SELECT * FROM vaccination WHERE vacc_type='$vacc_type'") or die($mysqli->error());

// We know user email exists if the rows returned are more than 0
if ( $result->num_rows > 0 ) {
    
 $_SESSION['alert'] = "<h4><b>Vacc already exists!</b><h4>";

    
}
else { // pet doesn't already exist in a database, proceed...


    $sql = "INSERT INTO vaccination (vacc_type, issue_date, vet_name) " 
            . "VALUES ('$vacc_type','$issue_date','$vet_name')";

    // Add add to the database
    if ( $mysqli->query($sql) ){

        
   $_SESSION['alert'] = "<h4><b>$vacc_type was added!<b></h4>";

    }

    else {
        
    $_SESSION['alert'] = "<h4><b>Registration failed!</b></h4>";
        
    }

  }
    
}

?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Vaccination</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><h4><i class= "fa fa-paw"> Pet's Health</i></h4></a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                          <i class= "fa fa-paw"></i>
                    </a>
                     <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-paw"></i> Pet's Health</a>
                        </li>
                    </ul>
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar">
                        </li>
                        <li class="active">
                            <a><i class="fa fa-dashboard fa-fw"></i><b> Dashboard</b><span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="myPets.php"><i class="fa fa-paw"></i> My Pets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                <li>
                                     <a href="vets.php"><i class="fa fa-user-md"></i> Vets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="petSitters.php"><i class ="fa fa-user"></i> Pet Sitters <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="myPets.php"><i class ="fa fa-reply"></i> Back <i class="fa fa-hand-o-left"></i></a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Page Content -->
       <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"> <i class="fa fa-plus-square"> Vaccination</i> 
                         <?php echo $_SESSION['alert'] ?>
                    </h3>
            
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" action="vaccination.php" method="post">
                                        <div class="form-group">
                                            <label> Vaccination type* </label>
                                            <input class="form-control" type="text" required="required" name="vacc_type">
                                        </div>
                                        <div class ="form-group">
                                            <label>Issue Date* </label>
                                             <div class="form-control">
                                             <input type= "datetime-local" type="date" required="required" name="issue_date">
                                             </div>
                                             </div>
                                             <div class="form-group">
                                            <label> Vet Name*</label>
                                            <input class="form-control" type="text" required="required" name="vet_name">
                                        </div>
                                       <button type="submit" class="btn btn-success" name="vaccination">
                                        <i class="fa fa-plus-square"></i>  Add Vaccination 
                                       </button>
                                    </form>
                                </div>
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
 
</body>
</html>
