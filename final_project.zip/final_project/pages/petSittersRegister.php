<?php
/* Registration process, inserts user info into the database 
 */
error_reporting(0);
require 'db.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['petSittersRegistration'])) {

        
    }
// Escape all $_POST variables to protect against SQL injections
$sitter_first_name = $mysqli->escape_string($_POST['sitter_first_name']);
$sitter_last_name = $mysqli->escape_string($_POST['sitter_last_name']);
$sitter_phone_number = $mysqli->escape_string($_POST['sitter_phone_number']);
$sitter_email = $mysqli->escape_string($_POST['sitter_email']);
$sitter_address = $mysqli->escape_string($_POST['sitter_address']);                                    
$sitter_specialization = $mysqli->escape_string($_POST['sitter_specialization']);     
// Check if user with the pet already exists
$result = $mysqli->query("SELECT * FROM petsitters WHERE sitter_email='$sitter_email'") or die($mysqli->error());

// We know user email exists if the rows returned are more than 0
if ( $result->num_rows > 0 ) {
    
 $_SESSION['alertsitter'] = "<h4><b>Email already registered!</b><h4>";

    
}
else { // pet doesn't already exist in a database, proceed...


    $sql = "INSERT INTO petsitters (sitter_first_name, sitter_last_name, sitter_phone_number, sitter_email, sitter_address, sitter_specialization) " 
            . "VALUES ('$sitter_first_name','$sitter_last_name','$sitter_phone_number','$sitter_email', '$sitter_address', '$sitter_specialization')";

    // Add add to the database
    if ( $mysqli->query($sql) ){

        
   $_SESSION['alertsitter'] = "<h4><b>$sitter_first_name was register!<b></h4>";

    }

    else {
        
    $_SESSION['alertsitter'] = "<h4><b>Registration failed!</b></h4>";
        
    }

  }
    
}

?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Profile</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><h4><i class= "fa fa-paw"> Pet's Health</i></h4></a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class= "fa fa-paw"></i>
                    </a>
                      <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-paw"></i> Pet's Health</a>
                        </li>
                    </ul>
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar">
                        </li>
                        <li class="active">
                            <a><i class="fa fa-dashboard fa-fw"></i><b> Dashboard</b><span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addPet.php"><i class="fa fa-plus"></i> Add Pet <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                <li>
                                     <a href="myPets.php"><i class="fa fa-paw"></i> My Pets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="vets.php"><i class ="fa fa-user-md"></i> Vets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="petSitters.php"><i class ="fa fa-user"></i> Pet Sitters <i class="fa fa-hand-o-right"></i></a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Page Content -->
       <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-user"> Register as a Pet Sitter </i>
                         <?php echo $_SESSION['alertsitter'] ?>
                    </h3>
            
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" action="petSittersRegister.php" method="post">
                                        <div class="form-group">
                                            <label> First Name*</label>
                                            <input class="form-control" type="text" required="required" name="sitter_first_name">
                                        </div>
                                        <div class="form-group">
                                            <label>Last Name* </label>
                                            <input class="form-control" type="text" required="required" name="sitter_last_name">
                                        </div>
                                        <div class="form-group">
                                            <label>Phone Number*</label>
                                            <input class="form-control" type="text"required="required" name="sitter_phone_number">
                                        </div>
                                        <div class="form-group">
                                            <label>Email*</label>
                                            <input class="form-control" type="email" required="required" name="sitter_email">
                                        </div>
                                        <div class="form-group">
                                            <label>Address*</label>
                                            <input class="form-control" type="text" required="required" name="sitter_address">
                                        </div>
                                        <div class="form-group">
                                            <label>Specialization*</label>
                                            <input class="form-control" type="text" required="required"  name="sitter_specialization">
                                        </div>
                                       
                                       <button type="submit" class="btn btn-success"  name="Register">
                                         <i class="fa fa-user"> Register</i>
                                       </button>
                                    </form>
                                </div>
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
 
</body>
</html>
