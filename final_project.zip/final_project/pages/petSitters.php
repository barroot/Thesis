<?php
/* Displays user information and some useful messages */
session_start();
error_reporting(0);
require 'db.php';  

// Check if user is logged in using the session variable
if ( $_SESSION['logged_in'] != 1 ) {
  $_SESSION['message'] = "You must log in before viewing your profile page!";
  header("location: error.php");    
}

?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Pet Sitters</title>
    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><h4><i class= "fa fa-paw"> Pet's Health</i></h4></a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                           <img src="logo_p.png" height="17px" width="22px">
                    </a>
                     <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-paw"></i> Pet's Health</a>
                        </li>
                    </ul>
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar">
                        </li>
                        <li class="active">
                            <a><i class="fa fa-dashboard fa-fw"></i><b> Dashboard</b><span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="addPet.php"><i class="fa fa-cloud-upload"></i> Add Pet <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                <li>
                                     <a href="myPets.php"><i class="fa fa-paw"></i> My Pets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="vets.php"><i class ="fa fa-user-md"></i> Vets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="profile.php"><i class ="fa fa-reply"></i> Back <i class="fa fa-hand-o-left"></i></a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>

        <!-- Page Content -->
        <div id="page-wrapper">
              
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header"> <i class="fa fa-user"> Pet Sitters </i></h3>
                          <div class="col-lg-2">
                              <a href="petSittersRegister.php" class="btn btn-success" role="button">
                              <i class="fa fa-user"> Register as a Pet Sitter</i></a>
                           </div>
                 <div class="row">
                        <h3 class="page-header"></h3>
                 </div>
                    <style>
                        #map{
                        height:600px;
                        width:100%;
                        }
                    </style>
          <div id="map"></div>
        <script>
        function initMap(){
        // Map options
        var options = {
        zoom:11,
        center:{lat:53.3603142,lng:-6.3150542}
        }

        // New map
       var map = new google.maps.Map(document.getElementById('map'), options);
      // Array of markers
       var markers = [
      
      ];

      // Loop through markers
      for(var i = 0;i < markers.length;i++){
        // Add marker
        addMarker(markers[i]);
      }

      // Add Marker Function
        function addMarker(props){
        var marker = new google.maps.Marker({
        position:props.coords,
        map:map,
          //icon:props.iconImage
        });

        // Check for customicon
        if(props.iconImage){
          // Set icon image
          marker.setIcon(props.iconImage);
        }

        // Check content
        if(props.content){
          var infoWindow = new google.maps.InfoWindow({
          content:props.content
          });
          marker.addListener('click', function(){
          infoWindow.open(map, marker);
          });
        }
      }
    }
   </script>
     <script async defer
     src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDVd4cqLgp8SJ9m9R2tx9iIMHgk-sYkeAI&callback=initMap">
  </script>
<!--
<div class="form">
                         
     <?php

     if(! $mysqli ) {
         die('Could not connect: ' . mysqli_error());
     }
         $sql = 'SELECT * FROM `petshealth`.`petsitters` ';                  
         $result = mysqli_query($mysqli, $sql);
                             
         echo '<table align="left" style="padding:25px">';
         echo '<tr bgcolor= "#e6e6e6"  >';
         echo'<td style= "width:130px"><h4> First Name </h4> </td>'; 
         echo'<td style= "width:130px"><h4> Last Name </h4></td>';
         echo'<td style= "width:130px"><h4> Phone Number </h4> </td>';
         echo'<td style= "width:130px"><h4> Email Address </h4></td>'; 
         echo'<td style= "width:130px"><h4> Address </h4> </td>';
         echo'<td style= "width:103px"><h4> Specialization </h4> </td>';
                            
                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) { 
                    $sitter_first_name = $row['sitter_first_name'];
	                $sitter_last_name =  $row['sitter_last_name'];
	                $sitter_phone_number = $row['sitter_phone_number'];
                    $sitter_email = $row['sitter_email'];  
                    $sitter_address = $row['sitter_address']; 
                    $sitter_specialization = $row['sitter_specialization'];

                     echo '<tr style="padding: 20px">';
                     echo '<td style= "font-size: 15px">'  .$sitter_first_name.    '</td>';
                     echo '<td style= "font-size: 15px">'  .$sitter_last_name.     '</td>';
                     echo '<td style= "font-size: 15px">'  .$sitter_phone_number.  '</td>';    
                     echo '<td style= "font-size: 15px">'  .$sitter_email.         '</td>';  
                     echo '<td style= "font-size: 15px">'  .$sitter_address.       '</td>';
                     echo '<td style= "font-size: 15px">'  .$sitter_specialization.'</td>';    					
	                 echo '</tr>';			
	                 echo '</form>';
                     }
                } else {
                    echo "0 results";
                    }  mysqli_close($mysqli);
    
         ?>	           
                      </div>
-->
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
 
</body>
</html>
