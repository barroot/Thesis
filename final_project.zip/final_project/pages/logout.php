<?php
/* Log out process, unsets and destroys session variables */
session_start();
session_unset();
session_destroy(); 
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Logout</title>
  <?php include 'css/css.html'; ?>
</head>

<body>
    <div class="form">
          <h1>Thanks for using Pet's Health </h1>  
          <p><img src="logo_p.png" height="45px" width="55px"></p>
          <a href="index.php"><button class="button button-block">Home</button></a>
    </div>
</body>
</html>
