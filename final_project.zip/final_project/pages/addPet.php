<?php
/* Registration process, inserts user info into the database 
 */
session_start();
 $_SESSION['alert'] = "";
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['addPet'])) {

        
    }
// Escape all $_POST variables to protect against SQL injections
$pet_type = $mysqli->escape_string($_POST['pet_type']);
$pet_name = $mysqli->escape_string($_POST['pet_name']);
$pet_breed = $mysqli->escape_string($_POST['pet_breed']);
$pet_weight = $mysqli->escape_string($_POST['pet_weight']);
$pet_gender = $mysqli->escape_string($_POST['pet_gender']);                                    
$pet_DOB = $mysqli->escape_string($_POST['pet_DOB']);
$picture_path = $mysqli->real_escape_string($_FILES['picture']['name']);
    //make sure the file type is image
     if (preg_match("!image!",$_FILES['picture']['type'])) {
            
            
     }
// Check if user with the pet already exists
$result = $mysqli->query("SELECT * FROM pets WHERE pet_name='$pet_name'") or die($mysqli->error());
                

// We know user email exists if the rows returned are more than 0
if ( $result->num_rows > 0 ) {
    
 $_SESSION['alert'] = "<h4><b>Pet already exists!</b><h4>";

    
}
else { // pet doesn't already exist in a database, proceed...


    $sql = "INSERT INTO pets (pet_type, pet_name, pet_breed, pet_weight, pet_gender, pet_DOB, picture) " 
            . "VALUES ('$pet_type','$pet_name','$pet_breed','$pet_weight', '$pet_gender', '$pet_DOB', '$picture_path' )";

  
   
    // Add add to the database
    if ( $mysqli->query($sql) ){
        
   $_SESSION['alert'] = "<h4><b>$pet_name was added!<b></h4>";

    }

    else {
        
    $_SESSION['alert'] = "<h4><b>Registration failed!</b></h4>";
        
    }
   
   

  }
    
}

?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Profile</title>

    <!-- Bootstrap Core CSS -->
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="../vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand"><h4><i class= "fa fa-paw"> Pet's Health</i></h4></a>
            </div>
            <!-- /.navbar-header -->

            <ul class="nav navbar-top-links navbar-right">
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class= "fa fa-paw"></i>
                    </a>
                      <ul class="dropdown-menu dropdown-user">
                        <li><a href="profile.php"><i class="fa fa-paw"></i> Pet's Health</a>
                        </li>
                    </ul>
                </li>
                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> User Profile</a>
                        </li>
                        <li><a href="#"><i class="fa fa-gear fa-fw"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
            <!-- /.navbar-top-links -->

            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar">
                        </li>
                        <li class="active">
                            <a><i class="fa fa-dashboard fa-fw"></i><b> Dashboard</b><span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="myPets.php"><i class="fa fa-paw"></i> My Pets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                <li>
                                     <a href="vets.php"><i class="fa fa-user-md"></i> Vets <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="petSitters.php"><i class ="fa fa-user"></i> Pet Sitters <i class="fa fa-hand-o-right"></i></a>
                                </li>
                                 <li>
                                    <a href="profile.php"><i class ="fa fa-reply"></i> Back <i class="fa fa-hand-o-left"></i></a>
                                </li>
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
            <!-- /.navbar-static-side -->
        </nav>
        <!-- Page Content -->
       <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="page-header"><i class="fa fa-cloud-upload"> Add New Pet </i> 
                         <?php echo $_SESSION['alert'] ?>
                    </h3>
            
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form role="form" action="addPet.php" method="post"  enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label> Pet Type*</label>
                                            <input class="form-control" type="text" required="required" name="pet_type">
                                        </div>
                                        <div class="form-group">
                                            <label>Name*</label>
                                            <input class="form-control" type="text" required="required" name="pet_name">
                                        </div>
                                        <div class="form-group">
                                            <label>Breed*</label>
                                            <input class="form-control" type="text" required="required" name="pet_breed">
                                        </div>
                                        <div class="form-group">
                                            <label>Weight*</label>
                                            <input class="form-control" type="text" required="required" name="pet_weight">
                                        </div>
                                        <div class="form-group">
                                            <label>Gender*</label>
                                           <select class="form-control" required="required" name="pet_gender">
                                              <option>Select</option>
                                              <option>Male</option>
                                              <option>Female</option>
                                           </select>
                                        </div>
                                        <div class ="form-group">
                                            <label>Date of Birth* </label>
                                             <div class="form-control">
                                             <input type= "datetime-local" type="date" required="required" name="pet_DOB">
                                             </div>                                                     
                                        </div>
                                         <div class ="form-group">
                                            <label>Picture </label>
                                            
                                            <input type="file" name="picture" accept="image/*">                   
                                                          
                                        </div>
                                        <br>
                                       <button type="submit" class="btn btn-success" name="addPet">
                                        <i class="fa fa-cloud-upload">  Add Pet </i>
                                       </button>
                                    </form>
                                </div>
                               
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="../vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="../vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="../dist/js/sb-admin-2.js"></script>
 
</body>
</html>
