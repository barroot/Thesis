-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.1.30-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win32
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for petshealth
CREATE DATABASE IF NOT EXISTS `petshealth` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `petshealth`;

-- Dumping structure for table petshealth.medication
CREATE TABLE IF NOT EXISTS `medication` (
  `medID` int(11) NOT NULL AUTO_INCREMENT,
  `medication` varchar(100) NOT NULL DEFAULT '0',
  `dose` varchar(50) NOT NULL DEFAULT '0',
  `fisrtAdministration` date NOT NULL,
  `lastAdministration` date NOT NULL,
  `frequency` varchar(100) NOT NULL DEFAULT '0',
  `petID` int(11) NOT NULL,
  PRIMARY KEY (`medID`),
  KEY `FK__pets` (`petID`),
  CONSTRAINT `FK__pets` FOREIGN KEY (`petID`) REFERENCES `pets` (`pet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table petshealth.medication: ~0 rows (approximately)
/*!40000 ALTER TABLE `medication` DISABLE KEYS */;
/*!40000 ALTER TABLE `medication` ENABLE KEYS */;

-- Dumping structure for table petshealth.notes
CREATE TABLE IF NOT EXISTS `notes` (
  `notes` varchar(500) DEFAULT NULL,
  `notes2` varchar(500) DEFAULT NULL,
  `petID` int(11) DEFAULT NULL,
  KEY `FK__notes` (`petID`),
  CONSTRAINT `FK__notes` FOREIGN KEY (`petID`) REFERENCES `pets` (`pet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table petshealth.notes: ~0 rows (approximately)
/*!40000 ALTER TABLE `notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `notes` ENABLE KEYS */;

-- Dumping structure for table petshealth.pets
CREATE TABLE IF NOT EXISTS `pets` (
  `pet_id` int(11) NOT NULL AUTO_INCREMENT,
  `pet_type` varchar(50) NOT NULL,
  `pet_name` varchar(50) NOT NULL,
  `pet_breed` varchar(50) NOT NULL,
  `pet_weight` double NOT NULL,
  `pet_gender` varchar(50) NOT NULL,
  `pet_DOB` date NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`pet_id`),
  KEY `Column 8` (`user_id`),
  CONSTRAINT `FK_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Dumping data for table petshealth.pets: ~11 rows (approximately)
/*!40000 ALTER TABLE `pets` DISABLE KEYS */;
INSERT INTO `pets` (`pet_id`, `pet_type`, `pet_name`, `pet_breed`, `pet_weight`, `pet_gender`, `pet_DOB`, `user_id`) VALUES
	(5, 'dog', 'Marcio', 'brees', 39, 'Female', '1987-09-12', NULL),
	(6, 'marcio', '123', 'bress', 43, 'Male', '1987-09-12', NULL),
	(7, 'marcio', 'rei', 'vira', 34, 'Male', '1986-09-12', NULL),
	(8, 'marcio', 'uo', 'virq', 49, 'Male', '1986-09-12', NULL),
	(9, 'marcio', 'eu', '34', 45, 'Male', '1986-09-12', NULL),
	(10, 'r', 'd', '', 0, 'Select', '1986-03-12', NULL),
	(11, '34', 'er45', '', 0, 'Select', '2000-05-12', NULL),
	(12, 'marcuo', '34', 'df', 0, 'Select', '2000-09-23', NULL),
	(13, '445555555', '', '', 0, 'Select', '1986-09-12', NULL),
	(14, 'marcio', '23', 'dog', 45, 'Male', '1987-09-09', NULL),
	(15, 'tadvfvf', 'vbgb', 'bggbg', 45, 'Male', '1987-05-12', NULL);
/*!40000 ALTER TABLE `pets` ENABLE KEYS */;

-- Dumping structure for table petshealth.petsitters
CREATE TABLE IF NOT EXISTS `petsitters` (
  `sitter_id` int(11) NOT NULL AUTO_INCREMENT,
  `sitter_first_name` varchar(50) NOT NULL DEFAULT '0',
  `sitter_last_name` varchar(50) NOT NULL DEFAULT '0',
  `sitter_phone_number` varchar(15) NOT NULL DEFAULT '0',
  `sitter_email` varchar(100) NOT NULL DEFAULT '0',
  `sitter_address` varchar(100) NOT NULL DEFAULT '0',
  `sitter_specialization` varchar(100) NOT NULL,
  PRIMARY KEY (`sitter_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table petshealth.petsitters: ~2 rows (approximately)
/*!40000 ALTER TABLE `petsitters` DISABLE KEYS */;
INSERT INTO `petsitters` (`sitter_id`, `sitter_first_name`, `sitter_last_name`, `sitter_phone_number`, `sitter_email`, `sitter_address`, `sitter_specialization`) VALUES
	(1, '55555', '5555', '', 'nedes.marcio@iclould.com', '', ''),
	(2, 'marcio', 'euclo', '08990000', 'nedes.marcio@gmail.com', '34-444', 'dog');
/*!40000 ALTER TABLE `petsitters` ENABLE KEYS */;

-- Dumping structure for table petshealth.users
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table petshealth.users: ~1 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`user_id`, `first_name`, `last_name`, `email`, `password`, `hash`, `active`) VALUES
	(2, 'Marcio', 'DeAbreu', 'nedes.marcio@gmail.com', '$2y$10$UQ9qPqq0z4xlNCBG4HtVrubu1j9NAs8hmUDDENpVJ5GuqE0Y5gS7y', '34ed066df378efacc9b924ec161e7639', 0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table petshealth.vaccination
CREATE TABLE IF NOT EXISTS `vaccination` (
  `vaccID` int(11) NOT NULL AUTO_INCREMENT,
  `vaccination` varchar(100) NOT NULL DEFAULT '0',
  `issueDate` date NOT NULL,
  `vetName` varchar(100) NOT NULL,
  `petID` int(11) NOT NULL,
  PRIMARY KEY (`vaccID`),
  KEY `FK__vaccination` (`petID`),
  CONSTRAINT `FK__vaccination` FOREIGN KEY (`petID`) REFERENCES `pets` (`pet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table petshealth.vaccination: ~0 rows (approximately)
/*!40000 ALTER TABLE `vaccination` DISABLE KEYS */;
/*!40000 ALTER TABLE `vaccination` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
